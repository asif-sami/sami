from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from .models import Job, Company, Application
from django.db.models import Q,Min,Max,Avg,Count
from .forms import ApplicationForm, RegistrationForm, JobForm, CompanyForm
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages 


def showalljobs(request):
    jobs = Job.objects.all()
    if request.GET.get('search'):
        search_query = request.GET.get('search')
        jobs = jobs.filter(Q(title__icontains=search_query) | 
                           Q(description__icontains=search_query)
                           |Q(company__name__icontains=search_query))
    min_salary = jobs.aggregate(Min('salary'))['salary__min']
    max_salary = jobs.aggregate(Max('salary'))['salary__max']
    location = Company.objects.values_list('location', flat=True).distinct()
    if request.GET.get('MIN'):
        min_salary = request.GET.get('MIN')
        jobs = jobs.filter(salary__gte=min_salary)
    if request.GET.get('MAX'):
        max_salary = request.GET.get('MAX')
        jobs = jobs.filter(salary__lte=max_salary)
    if request.GET.get('location'):
        location = request.GET.get('location')
        jobs = jobs.filter(location__icontains=location)
    context={
        "jobs": jobs,
        "min_salary": min_salary,   
        "max_salary": max_salary,
        "location": location,
        "search_query": request.GET.get('search', '')
    }
    return render(request, 'base.html', context)
    
def jobdetails(request, job_id):
    job = Job.objects.get(id=job_id)
    applications = Application.objects.filter(job=job)
    context = {
        'job': job,
        'applications': applications
    }
    return render(request, 'jobdetails.html', context)
def apply(request, job_id):
    
    job = Job.objects.get(id=job_id)
      
        

    if job.total_applications <= 0:
        return HttpResponse("No applications left for this job.")
        return redirect('', job_id=job.id)
    if request.method == 'POST':
        if Application.objects.filter(job=job, applicant=request.user).exists():
            messages.error(request, "You have already applied for this job.") 
            return redirect('jobdetails', job_id=job.id)
        
          
        form=ApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            application = form.save(commit=False)
            application.job = job
            application.applicant = request.user
            application.save()
            job.total_applications -= 1
            job.save()
            messages.success(request, "Application submitted successfully.")
            return redirect('home')

    else:
        form = ApplicationForm()
    return render(request, 'apply.html', {'job': job, 'form': form})
def profile(request):
    user = request.user
    Applications = user.applicants.all()
    if request.GET.get('status'):
        status = request.GET.get('status')
        Applications = Applications.filter(status=status)
    else:
        status = "pending"
    context = {
        'user': user,
        'Applications': Applications,
        'status': status
    }
    return render(request, 'profile.html', context)
def postanewjob(request):
    if request.method == 'POST':
        form = JobForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.posted_by = request.user
            job.save()
            messages.success(request, 'Job posted successfully.')
            return redirect('home')
    else:
        form = JobForm()
    return render(request, 'postjobs.html', {'form': form})
def seepostedjobs(request):
    jobs = Job.objects.filter(posted_by=request.user)
    return render(request, 'postedjobs.html', {'jobs': jobs})
def list(request, job_id):
    job = Job.objects.get(id=job_id)
    applicants = job.applicants.all()
    context = {
        'job': job,
        'applicants': applicants
    }
    return render(request, '', context)
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})
def Register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            authenticated_user = authenticate(username=user.username, password=form.cleaned_data['password1'])
            if authenticated_user is not None:
                login(request, authenticated_user)
                messages.success(request, 'Registration successful.')
                return redirect('home')
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})
def logout_view(request):
    logout(request)
    return redirect('home')  
def deletejob(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    job.delete()
    messages.success(request, 'Job deleted successfully.')
    return redirect('seepostedjobs')
def editjob(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    if request.method == 'POST':
        form = JobForm(request.POST, instance=job)
        if form.is_valid():
            form.save()
            messages.success(request, 'Job updated successfully.')
            return redirect('seepostedjobs')
    else:
        form = JobForm(instance=job)
    return render(request, 'editjob.html', {'form': form, 'job': job})
def seeallapplications(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    applications = Application.objects.filter(job=job)
    context = {
        'job': job,
        'applications': applications
    }
    return render(request, 'seeapplications.html', context)
def approve(request, application_id):
    application = get_object_or_404(Application, id=application_id)
    application.status = 'Accepted'
    application.save()
    messages.success(request, 'Application approved successfully.')
    return redirect('seeallapplications', job_id=application.job.id)
def reject(request, application_id):
    application = get_object_or_404(Application, id=application_id)
    application.status = 'Rejected'
    application.save()
    messages.success(request, 'Application rejected successfully.')
    return redirect('seeallapplications', job_id=application.job.id)