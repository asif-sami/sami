from django import forms
from .models import Company, Job, Application
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
class CompanyForm(forms.ModelForm):
    class Meta:
        model = Company
        fields = ['name', 'location', 'description']

class JobForm(forms.ModelForm):
    class Meta:
        model = Job
        fields = ['title', 'company', 'description', 'location', 'salary', 'total_applications']

class ApplicationForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = [ 'cover_letter', 'resume']
class RegistrationForm(UserCreationForm):
    class Meta:
        email= forms.EmailField(required=True)
        username=forms.CharField(max_length=150, required=True)
        model = User
        fields = ['username', 'email', 'password1', 'password2']        
        widgets = {
            'password1': forms.PasswordInput(),
            'password2': forms.PasswordInput(),
        }