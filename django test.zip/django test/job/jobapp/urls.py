from django.contrib import admin
from django.urls import include, path
from .import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.Register_view, name='register'),
    path('', views.showalljobs, name='home'),
    path('jobdetails/<int:job_id>/', views.jobdetails, name='jobdetails'),
    path('apply/<int:job_id>/', views.apply, name='apply'),
    path('profile/', views.profile, name='profile'),
    path('postanewjob/', views.postanewjob, name='postanewjob'),
    path('seepostedjobs/', views.seepostedjobs, name='seepostedjobs'),
    path('deletejob/<int:job_id>/', views.deletejob, name='deletejob'),
    path('editjob/<int:job_id>/', views.editjob, name='editjob'),
    path('seeallapplications/<int:job_id>/', views.seeallapplications, name='seeallapplications'),
    path('approve/<int:application_id>/', views.approve, name='approve'),
    path('reject/<int:application_id>/', views.reject, name='reject'),
]
