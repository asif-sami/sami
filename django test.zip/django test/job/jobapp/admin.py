from django.contrib import admin
from .models import Company, Job, Application

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ['name', 'location', 'user']
    list_filter = ['location']
    search_fields = ['name', 'location']
    ordering = ['name']
    fieldsets = (
        ('Company Info', {
            'fields': ('name', 'location')
        }),
        ('Ownership', {
            'fields': ('user',)
        }),
    )

@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ['title', 'company', 'location', 'salary', 'posted_date', 'posted_by', 'total_applications']
    list_filter = ['location', 'company', 'posted_date']
    search_fields = ['title', 'description', 'company__name']
    ordering = ['-posted_date']
    readonly_fields = ['posted_date', 'total_applications']
    fieldsets = (
        ('Job Details', {
            'fields': ('title', 'description', 'location', 'salary')
        }),
        ('Company & Poster', {
            'fields': ('company', 'posted_by')
        }),
        ('Metadata', {
            'fields': ('posted_date', 'total_applications')
        }),
    )

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ['job', 'applicant', 'status', 'applied_date']
    list_filter = ['status', 'applied_date']
    search_fields = ['job__title', 'applicant__username']
    ordering = ['-applied_date']
    readonly_fields = ['applied_date']
    fieldsets = (
        ('Application Info', {
            'fields': ('job', 'applicant', 'status')
        }),
        ('Timestamps', {
            'fields': ('applied_date',)
        }),
    )
